<footer>
  <div class="copyright-info">
    <p class="pull-right"><a href="http://www.elitekillerZ.com" target="_blank">E-CreW Server Statitics</a> <strong>.</strong> | Powered &amp; Modified by <a href="S!R.ReaDy<3" target="_blank">S!R.ReaDy<3</a></p>
  </div>
  <div class="clearfix"></div>
</footer>
