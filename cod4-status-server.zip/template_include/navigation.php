<?php
mysql_select_db($database_ststsconfig, $ststsconfig);
$query_nav_servers = "SELECT id, server_name FROM servers ORDER BY id ASC";
$nav_servers = mysql_query($query_nav_servers, $ststsconfig) or die(mysql_error());
$row_nav_servers = mysql_fetch_assoc($nav_servers);
$totalRows_nav_servers = mysql_num_rows($nav_servers);

mysql_select_db($database_ststsconfig, $ststsconfig);
$query_nav_servers_admin = "SELECT id, server_name FROM servers ORDER BY id ASC";
$nav_servers_admin = mysql_query($query_nav_servers_admin, $ststsconfig) or die(mysql_error());
$row_nav_servers_admin = mysql_fetch_assoc($nav_servers_admin);
$totalRows_nav_servers_admin = mysql_num_rows($nav_servers_admin);
?>

<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
  <div class="menu_section">
    <h3>general menu</h3>
    <ul class="nav side-menu">
      <li><a><i class="fa fa-home"></i> Home <span class="fa fa-chevron-down"></span></a>
        <ul class="nav child_menu" style="display: none">
          <li><a href="/">Dashboard</a></li>
        </ul>
      </li>
      <?php if ($totalRows_nav_servers > 0) { // Show if recordset not empty ?>
        <li><a><i class="fa fa-desktop"></i> Servers <span class="fa fa-chevron-down"></span></a>
          <ul class="nav child_menu" style="display: none">
            <?php do { ?>
              <li><a href="/server-details.php?id=<?php echo $row_nav_servers['id']; ?>"><?php echo $row_nav_servers['server_name']; ?></a> </li>
              <?php } while ($row_nav_servers = mysql_fetch_assoc($nav_servers));?>
          </ul>
        </li>
        <?php } // Show if recordset not empty ?>
      <li><a><i class="fa fa-hand-paper-o"></i> Banned Players <span class="fa fa-chevron-down"></span></a>
        <ul class="nav child_menu" style="display: none">
          <li><a href="/banned.php">List of Banned players</a> </li>
        </ul>
      </li>
    </ul>
  </div>
  <?php if ((isset($_SESSION['MM_Username'])) && ($row_loggedin['power']==100)) { ?>
  <div class="menu_section">
    <h3>Administration</h3>
    <ul class="nav side-menu">
      <li><a><i class="fa fa-bug"></i> Server Settings <span class="fa fa-chevron-down"></span></a>
        <ul class="nav child_menu" style="display: none">
          <li><a href="servers.php">My Servers</a> </li>
          <li><a href="server-admins.php">Server Admins</a> </li>
          <li><a href="server-comunity.php">Comunity Settings</a> </li>
        </ul>
      </li>
    </ul>
  </div>
  <?php if ($totalRows_nav_servers > 0) { // Show if recordset not empty ?>
  <div class="menu_section">
    <h3>Admin Actions</h3>
    <ul class="nav side-menu">
      <li><a><i class="fa fa-windows"></i> Admin Actions <span class="fa fa-chevron-down"></span></a>
        <ul class="nav child_menu" style="display: none">
          <?php do { ?>
            <li><a href="/admin-actions.php?id=<?php echo $row_nav_servers_admin['id']; ?>"><?php echo $row_nav_servers_admin['server_name']; ?></a> </li>
            <?php } while ($row_nav_servers_admin = mysql_fetch_assoc($nav_servers_admin)); ?>
        </ul>
      </li>
    </ul>
  </div>
  <?php }; ?>
  <?php }; ?>
</div>
<?php
mysql_free_result($nav_servers);

mysql_free_result($nav_servers_admin);
?>
