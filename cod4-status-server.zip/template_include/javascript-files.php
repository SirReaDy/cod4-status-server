<script src="/js/bootstrap.min.js" type="text/javascript"></script> 
<script src="/js/progressbar/bootstrap-progressbar.min.js" type="text/javascript"></script> 
<script src="/js/nicescroll/jquery.nicescroll.min.js" type="text/javascript"></script> 
<script src="/js/gauge/gauge.min.js" type="text/javascript"></script> 
<script src="/js/icheck/icheck.min.js" type="text/javascript"></script> 
<script src="/js/custom.js" type="text/javascript"></script> 
<script type="text/javascript">NProgress.done();</script>